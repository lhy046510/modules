from  imdbpie import Imdb
imdb = Imdb()
ala = imdb.find_by_title("Cesarzowa") 
print ("Ala",ala)
